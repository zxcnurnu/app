<?php
// register.php
include 'config.php';
include 'functions.php';

// Функции валидации
function validate_phone($phone) {
    // Проверка формата +7XXXXXXXXXX (11 цифр)
    return preg_match('/^\+7\d{10}$/', $phone);
}

function validate_email($email) {
    // Проверка формата email и наличия @
    return filter_var($email, FILTER_VALIDATE_EMAIL) && strpos($email, '@') !== false;
}

function validate_full_name($full_name) {
    // Проверка что ФИО состоит ровно из 3 слов (разделенных пробелами)
    $words = explode(' ', trim($full_name));
    return count($words) === 3 && strlen($full_name) <= 100;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $login = trim($_POST['login']);
    $password = $_POST['password'];
    
    $errors = [];
    
    // Валидация полей
    if (empty($full_name)) {
        $errors[] = "ФИО обязательно";
    } elseif (!validate_full_name($full_name)) {
        $errors[] = "ФИО должно состоять ровно из 3 слов (Фамилия Имя Отчество) и быть не длиннее 100 символов";
    }
    
    if (empty($phone)) {
        $errors[] = "Телефон обязателен";
    } elseif (!validate_phone($phone)) {
        $errors[] = "Неверный формат телефона. Используйте формат +7XXXXXXXXXX";
    }
    
    if (empty($email)) {
        $errors[] = "Email обязателен";
    } elseif (!validate_email($email)) {
        $errors[] = "Неверный формат email. Email должен содержать @ и быть в правильном формате (например, user@example.com)";
    } elseif (strlen($email) > 50) {
        $errors[] = "Email слишком длинный (макс. 50 символов)";
    }
    
    if (empty($login)) {
        $errors[] = "Логин обязателен";
    } elseif (strlen($login) < 4 || strlen($login) > 20) {
        $errors[] = "Логин должен быть от 4 до 20 символов";
    } elseif (!preg_match('/^[a-zA-Z0-9_]+$/', $login)) {
        $errors[] = "Логин может содержать только буквы, цифры и подчеркивание";
    }
    
    if (empty($password)) {
        $errors[] = "Пароль обязателен";
    } elseif (strlen($password) < 6) {
        $errors[] = "Пароль должен быть не менее 6 символов";
    } elseif (strlen($password) > 30) {
        $errors[] = "Пароль слишком длинный (макс. 30 символов)";
    }
    
    // Проверка уникальности
    if (empty($errors)) {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE email = ? OR login = ?");
        $stmt->execute([$email, $login]);
        if ($stmt->fetchColumn() > 0) {
            $errors[] = "Email или логин уже используются";
        }
    }
    
    if (empty($errors)) {
        $password_hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("
            INSERT INTO users (full_name, phone, email, login, password) 
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([$full_name, $phone, $email, $login, $password_hash]);
        
        $_SESSION['success'] = "Регистрация прошла успешно! Теперь войдите в систему.";
        header("Location: login.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Регистрация | СпортGo</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f5f5f5; }
        .container { max-width: 500px; margin: 50px auto; padding: 20px; background: white; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        h1 { text-align: center; color: #2c3e50; }
        .form-group { margin-bottom: 30px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box; }
        input:invalid { border-color: #e74c3c; }
        button { width: 100%; padding: 12px; background: rgb(216, 219, 52); color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 16px; }
        button:hover { background:rgb(80, 206, 42); }
        .error { color: #e74c3c; margin-bottom: 10px; }
        .success { color: #27ae60; margin-bottom: 10px; }
        .login-link { text-align: center; margin-top: 15px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Регистрация</h1>
        
        <?php if (!empty($errors)): ?>
            <div class="error">
                <?php foreach ($errors as $error): ?>
                    <p><?= htmlspecialchars($error) ?></p>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <form method="POST" novalidate>
            <div class="form-group">
                <label>ФИО (Фамилия Имя Отчество):</label>
                <input type="text" name="full_name" required 
                       value="<?= htmlspecialchars($_POST['full_name'] ?? '') ?>"
                       maxlength="100"
                       pattern="^[А-Яа-яЁёA-Za-z]+\s[А-Яа-яЁёA-Za-z]+\s[А-Яа-яЁёA-Za-z]+$"
                       title="Введите ФИО ровно из 3 слов (Фамилия Имя Отчество) через пробел">
            </div>
            <div class="form-group">
                <label>Телефон (формат: +7XXXXXXXXXX):</label>
                <input type="tel" name="phone" required 
                       pattern="\+7\d{10}" 
                       value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>"
                       placeholder="+71234567890">
            </div>
            <div class="form-group">
                <label>Email:</label>
                <input type="email" name="email" required 
                       value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                       maxlength="50"
                       title="Введите корректный email (например, user@example.com)">
            </div>
            <div class="form-group">
                <label>Логин (4-20 символов, буквы, цифры и _):</label>
                <input type="text" name="login" required 
                       value="<?= htmlspecialchars($_POST['login'] ?? '') ?>"
                       pattern="[a-zA-Z0-9_]{4,20}"
                       title="Только буквы, цифры и подчеркивание, от 4 до 20 символов">
            </div>
            <div class="form-group">
                <label>Пароль (6-30 символов):</label>
                <input type="password" name="password" required 
                       minlength="6" maxlength="30">
            </div>
            <button type="submit">Зарегистрироваться</button>
        </form>
        
        <div class="login-link">
            <p>Уже есть аккаунт? <a href="login.php">Войти</a></p>
        </div>
    </div>
</body>
</html>