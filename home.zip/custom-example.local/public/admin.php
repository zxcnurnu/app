<?php
// admin.php
include 'config.php';
include 'functions.php';
check_admin();

$orders = get_all_orders($pdo);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $order_id = (int)$_POST['order_id'];
    $new_status = $_POST['new_status'];
    
    $stmt = $pdo->prepare("UPDATE orders SET status = ? WHERE order_id = ?");
    $stmt->execute([$new_status, $order_id]);
    
    // Если статус изменен на "cancelled" или "completed", возвращаем инвентарь
    if ($new_status === 'cancelled' || $new_status === 'completed') {
        $stmt = $pdo->prepare("
            UPDATE equipment e
            JOIN orders o ON e.equipment_id = o.equipment_id
            SET e.available_quantity = e.available_quantity + 1
            WHERE o.order_id = ?
        ");
        $stmt->execute([$order_id]);
    }
    
    header("Location: admin.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Панель администратора | СпортGo</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f5f5f5; }
        .container { max-width: 1200px; margin: 20px auto; padding: 20px; background: white; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; padding-bottom: 15px; border-bottom: 1px solid #eee; }
        h1 { color: #2c3e50; }
        .logout-btn { padding: 10px 15px; background: #e74c3c; color: white; text-decoration: none; border-radius: 4px; }
        .logout-btn:hover { background: #c0392b; }
        .orders-table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        .orders-table th, .orders-table td { padding: 12px; text-align: left; border-bottom: 1px solid #eee; }
        .orders-table th { background-color: #f8f9fa; position: sticky; top: 0; }
        .status-form { display: flex; gap: 10px; align-items: center; }
        .status-select { padding: 6px; border-radius: 4px; border: 1px solid #ddd; }
        .update-btn { padding: 6px 12px; background: #3498db; color: white; border: none; border-radius: 4px; cursor: pointer; }
        .update-btn:hover { background: #2980b9; }
        .status-new { background-color: #e3f2fd; }
        .status-confirmed { background-color: #e8f5e9; }
        .status-completed { background-color: #f5f5f5; }
        .status-cancelled { background-color: #ffebee; }
        @media (max-width: 768px) {
            .container { overflow-x: auto; }
            .orders-table { font-size: 14px; }
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>Панель администратора</h1>
            <a href="logout.php" class="logout-btn">Выйти</a>
        </header>
        
        <h2>Все заказы</h2>
        
        <table class="orders-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Клиент</th>
                    <th>Телефон</th>
                    <th>Email</th>
                    <th>Инвентарь</th>
                    <th>Период аренды</th>
                    <th>Пункт выдачи</th>
                    <th>Стоимость</th>
                    <th>Статус</th>
                    <th>Действия</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($orders as $order): ?>
                    <tr class="status-<?= $order['status'] ?>">
                        <td><?= $order['order_id'] ?></td>
                        <td><?= htmlspecialchars($order['full_name']) ?></td>
                        <td><?= htmlspecialchars($order['phone']) ?></td>
                        <td><?= htmlspecialchars($order['email']) ?></td>
                        <td><?= htmlspecialchars($order['equipment_name']) ?></td>
                        <td>
                            <?= date('d.m.Y H:i', strtotime($order['start_time'])) ?> -<br>
                            <?= date('d.m.Y H:i', strtotime($order['end_time'])) ?>
                        </td>
                        <td><?= htmlspecialchars($order['address']) ?></td>
                        <td><?= number_format($order['total_price'], 2) ?>₽</td>
                        <td>
                            <?php 
                            $statuses = [
                                'new' => 'Новый',
                                'confirmed' => 'Подтвержден',
                                'completed' => 'Выполнен',
                                'cancelled' => 'Отменен'
                            ];
                            echo $statuses[$order['status']];
                            ?>
                        </td>
                        <td>
                            <form class="status-form" method="POST">
                                <input type="hidden" name="order_id" value="<?= $order['order_id'] ?>">
                                <select name="new_status" class="status-select">
                                    <option value="new" <?= $order['status'] === 'new' ? 'selected' : '' ?>>Новый</option>
                                    <option value="confirmed" <?= $order['status'] === 'confirmed' ? 'selected' : '' ?>>Подтвержден</option>
                                    <option value="completed" <?= $order['status'] === 'completed' ? 'selected' : '' ?>>Выполнен</option>
                                    <option value="cancelled" <?= $order['status'] === 'cancelled' ? 'selected' : '' ?>>Отменен</option>
                                </select>
                                <button type="submit" name="update_status" class="update-btn">Обновить</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>