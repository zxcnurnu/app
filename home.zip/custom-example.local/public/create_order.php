<?php
// create_order.php
include 'config.php';
include 'functions.php';
check_auth();

$equipment = $pdo->query("SELECT * FROM equipment WHERE available_quantity > 0")->fetchAll();
$points = $pdo->query("SELECT * FROM pickup_points")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $equipment_id = (int)$_POST['equipment_id'];
    $start_time = $_POST['start_time'];
    $end_time = $_POST['end_time'];
    $point_id = (int)$_POST['point_id'];
    $payment_method = $_POST['payment_method'];
    
    // Расчет часов
    $hours = (strtotime($end_time) - strtotime($start_time)) / 3600;
    
    // Получение цены
    $stmt = $pdo->prepare("SELECT price_per_hour FROM equipment WHERE equipment_id = ?");
    $stmt->execute([$equipment_id]);
    $price = $stmt->fetchColumn();
    $total_price = $hours * $price;
    
    // Создание заказа
    $stmt = $pdo->prepare("
        INSERT INTO orders 
        (user_id, equipment_id, point_id, start_time, end_time, total_price, payment_method) 
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([
        $_SESSION['user_id'],
        $equipment_id,
        $point_id,
        $start_time,
        $end_time,
        $total_price,
        $payment_method
    ]);
    
    // Обновление доступного количества
    $stmt = $pdo->prepare("UPDATE equipment SET available_quantity = available_quantity - 1 WHERE equipment_id = ?");
    $stmt->execute([$equipment_id]);
    
    header("Location: dashboard.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Оформление заказа | СпортGo</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f5f5f5; }
        .container { max-width: 600px; margin: 20px auto; padding: 20px; background: white; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        h1 { text-align: center; color: #2c3e50; margin-bottom: 20px; }
        .form-group { margin-bottom: 20px; }
        label { display: block; margin-bottom: 8px; font-weight: bold; }
        select, input { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box; font-size: 16px; }
        .radio-group { display: flex; gap: 15px; margin: 15px 0; }
        .radio-group label { display: flex; align-items: center; font-weight: normal; }
        .radio-group input { width: auto; margin-right: 5px; }
        button { width: 100%; padding: 12px; background: rgb(216, 219, 52); color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 16px; }
        button:hover { background: rgb(80, 206, 42); }
        .back-link { display: block; text-align: center; margin-top: 15px; }
        @media (max-width: 480px) {
            .container { padding: 15px; }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Оформление заказа</h1>
        
        <form method="POST">
            <div class="form-group">
                <label>Спортивный инвентарь:</label>
                <select name="equipment_id" required>
                    <?php foreach($equipment as $item): ?>
                        <option value="<?= $item['equipment_id'] ?>">
                            <?= htmlspecialchars($item['name']) ?> 
                            (<?= $item['price_per_hour'] ?>₽/час)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label>Дата и время начала аренды:</label>
                <input type="datetime-local" name="start_time" required>
            </div>
            
            <div class="form-group">
                <label>Дата и время окончания аренды:</label>
                <input type="datetime-local" name="end_time" required>
            </div>
            
            <div class="form-group">
                <label>Пункт выдачи:</label>
                <select name="point_id" required>
                    <?php foreach($points as $point): ?>
                        <option value="<?= $point['point_id'] ?>">
                            <?= htmlspecialchars($point['address']) ?> 
                            (<?= htmlspecialchars($point['working_hours']) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label>Способ оплаты:</label>
                <div class="radio-group">
                    <label><input type="radio" name="payment_method" value="cash" checked> Наличные</label>
                    <label><input type="radio" name="payment_method" value="card"> Карта</label>
                </div>
            </div>
            
            <button type="submit">Подтвердить заказ</button>
        </form>
        
        <a href="dashboard.php" class="back-link">← Вернуться в личный кабинет</a>
    </div>
</body>
</html>