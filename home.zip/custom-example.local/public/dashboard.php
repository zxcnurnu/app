<?php
// dashboard.php
include 'config.php';
include 'functions.php';
check_auth();

$orders = get_user_orders($_SESSION['user_id'], $pdo);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Личный кабинет | СпортGo</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f5f5f5; }
        .container { max-width: 1000px; margin: 20px auto; padding: 20px; background: white; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; padding-bottom: 15px; border-bottom: 1px solid #eee; }
        .welcome { color: #2c3e50; }
        .btn { padding: 10px 15px; background: rgb(216, 219, 52); color: white; text-decoration: none; border-radius: 4px; }
        .btn:hover { background: rgb(80, 206, 42); }
        .logout-btn { background: #e74c3c; }
        .logout-btn:hover { background: #c0392b; }
        .orders-table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        .orders-table th, .orders-table td { padding: 12px; text-align: left; border-bottom: 1px solid #eee; }
        .orders-table th { background-color: #f8f9fa; }
        .status-new { color: #3498db; }
        .status-confirmed { color: #27ae60; }
        .status-completed { color: #7f8c8d; }
        .status-cancelled { color: #e74c3c; }
        .no-orders { text-align: center; padding: 20px; color: #7f8c8d; }
        .create-order-btn { display: block; width: 200px; margin: 20px auto; text-align: center; }
        @media (max-width: 768px) {
            .container { padding: 10px; }
            header { flex-direction: column; align-items: flex-start; }
            .user-actions { margin-top: 10px; }
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1 class="welcome">Добро пожаловать, <?= htmlspecialchars($_SESSION['full_name']) ?>!</h1>
            <div class="user-actions">
                <a href="create_order.php" class="btn">Создать заказ</a>
                <a href="logout.php" class="btn logout-btn">Выйти</a>
            </div>
        </header>
        
        <h2>История заказов</h2>
        
        <?php if (count($orders) > 0): ?>
            <table class="orders-table">
                <thead>
                    <tr>
                        <th>Инвентарь</th>
                        <th>Дата начала</th>
                        <th>Дата окончания</th>
                        <th>Пункт выдачи</th>
                        <th>Стоимость</th>
                        <th>Статус</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orders as $order): ?>
                        <tr>
                            <td><?= htmlspecialchars($order['equipment_name']) ?></td>
                            <td><?= date('d.m.Y H:i', strtotime($order['start_time'])) ?></td>
                            <td><?= date('d.m.Y H:i', strtotime($order['end_time'])) ?></td>
                            <td><?= htmlspecialchars($order['address']) ?></td>
                            <td><?= number_format($order['total_price'], 2) ?>₽</td>
                            <td class="status-<?= $order['status'] ?>">
                                <?php 
                                $statuses = [
                                    'new' => 'Новый',
                                    'confirmed' => 'Подтвержден',
                                    'completed' => 'Выполнен',
                                    'cancelled' => 'Отменен'
                                ];
                                echo $statuses[$order['status']];
                                ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="no-orders">
                <p>У вас пока нет заказов</p>
                <a href="create_order.php" class="btn create-order-btn">Оформить первый заказ</a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>